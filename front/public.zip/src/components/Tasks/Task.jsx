import React from 'react';
import "./Task";

const Task = (props) => {
return (
<div>
    Tasks
   <p><a href="/projects">Back to projects list</a></p> 
</div>
)
};

export default Task;